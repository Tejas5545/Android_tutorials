package com.example.tutorial06;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    EditText edusn,edpass;
    Button btnlogin;
    SharedPreferences sh;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edusn=findViewById(R.id.usn);
        edpass=findViewById(R.id.pass);
        btnlogin=findViewById(R.id.btnlogin);
        final Pattern p= Patterns.EMAIL_ADDRESS;
        sh = getSharedPreferences("login_det", Context.MODE_PRIVATE);
        editor = sh.edit();
        String SharedPref_email = sh.getString("email","");
        if(!SharedPref_email.equals("")){
            Intent intent = new Intent(MainActivity.this,WelcomePage.class);
            startActivity(intent);
            finish();
        }

            btnlogin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (p.matcher(edusn.getText().toString()).matches()) {
                        if (edusn.getText().toString().equals("admin@gmail.com") && edpass.getText().toString().equals("admin")) {
                            Intent i = new Intent(getApplicationContext(), WelcomePage.class);

                            editor.putString("email",edusn.getText().toString().trim());
                            editor.commit();
                            startActivity(i);
                            finish();
                        } else {
                            Toast.makeText(getApplicationContext(), "Invalid Credentials", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Re Enter valid Email Address", Toast.LENGTH_LONG).show();
                    }
                }
            });
//        }
    }
}