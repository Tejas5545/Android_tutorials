package com.example.tutorial07;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    EditText edu,edp;
    DatabaseHelper db;
    Button btnlogin;
    SharedPreferences sh;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edu=findViewById(R.id.eml);
        edp=findViewById(R.id.pwd);
        btnlogin=findViewById(R.id.btnl);
        final Pattern p= Patterns.EMAIL_ADDRESS;
        sh = getSharedPreferences("login_det", Context.MODE_PRIVATE);
        editor = sh.edit();
        String SharedPref_email = sh.getString("email","");
        if(!SharedPref_email.equals("")) {
            Intent intent = new Intent(MainActivity.this, Welcome.class);
            startActivity(intent);
            finish();
        }
        db=new DatabaseHelper(getApplicationContext());
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (p.matcher(edu.getText().toString()).matches()) {
                    if (db.FetchData(edu.getText().toString(), edp.getText().toString())) {
                        Intent i = new Intent(getApplicationContext(), Welcome.class);
                        editor.putString("email",edu.getText().toString().trim());
                        editor.commit();
                        startActivity(i);
                    } else {
                        Toast.makeText(getApplicationContext(), "invalid Credentials", Toast.LENGTH_LONG).show();
                    }
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Re Enter valid Email Address", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    public void register(View view) {
        Intent i=new Intent(getApplicationContext(),Register.class);
        startActivity(i);
    }
}