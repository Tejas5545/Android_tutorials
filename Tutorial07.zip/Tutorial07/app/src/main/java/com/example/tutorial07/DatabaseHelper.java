package com.example.tutorial07;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DBNAME="Student.db";
    public static final String TBNAME="user";
    public static final String COL1="id";
    public static final String COL2="firstname";
    public static final String COL3="surname";
    public static final String COL4="username";
    public static final String COL5="password";
    public static final String COL6="gender";
    public static final String COL7="city";
    public static final String COL8="status";
    public DatabaseHelper(@Nullable Context context) {
        super(context, DBNAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sqlcreate="CREATE TABLE if not exists "+TBNAME+
                "("+COL1+" INTEGER PRIMARY KEY AUTOINCREMENT,"
                +COL2+" TEXT,"
                +COL3+" TEXT,"
                +COL4+" TEXT,"
                +COL5+" TEXT,"
                +COL6+" TEXT,"
                +COL7+" TEXT,"
                +COL8+" TEXT)";
Log.i("CreateSql",sqlcreate);
        db.execSQL(sqlcreate);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+TBNAME);
        onCreate(db);
    }
    public boolean InsertData(String fname,String lname,String uname,String password,String gender,String city,String status)
    {
        SQLiteDatabase db=getReadableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(COL2,fname);
        cv.put(COL3,lname);
        cv.put(COL4,uname);
        cv.put(COL5,password);
        cv.put(COL6,gender);
        cv.put(COL7,city);
        cv.put(COL8,status);
        long res=db.insert(TBNAME,null,cv);
        if(res!=-1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public boolean FetchData(String username,String password)
    {
        SQLiteDatabase db=getWritableDatabase();
        String sql="SELECT * FROM user WHERE username = '"+username+"' and password = '"+password+"'";
        Cursor c=null;
        try
        {
            c=db.rawQuery(sql,null);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        if(c!=null && c.getCount()>0){
            c.close();
            return true;
        }
        else{
            c.close();
            return false;
        }
    }
}
