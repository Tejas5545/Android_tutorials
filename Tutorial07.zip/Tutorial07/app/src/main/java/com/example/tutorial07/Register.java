package com.example.tutorial07;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import java.util.regex.Pattern;

public class Register extends AppCompatActivity {

    EditText fname,lname,eml,pass;
    Spinner spl;
    Switch sp;
    RadioButton rgm,rgf;
    CheckBox chk;
    Button btnregister;
    DatabaseHelper mydb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        fname=findViewById(R.id.fn);
        lname=findViewById(R.id.ln);
        eml=findViewById(R.id.eml);
        pass=findViewById(R.id.pass);
        spl=findViewById(R.id.cty);
        sp=findViewById(R.id.sw);
        rgm=findViewById(R.id.gnderm);
        rgf=findViewById(R.id.genderf);
        chk=findViewById(R.id.chkprof);
        final Pattern p= Patterns.EMAIL_ADDRESS;
        btnregister=findViewById(R.id.btnsup);
        mydb=new DatabaseHelper(getApplicationContext());
        btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sp.isChecked())
                {
                    if(p.matcher(eml.getText().toString()).matches())
                    {
                        String fn=fname.getText().toString();
                        String ln=lname.getText().toString();
                        String em=eml.getText().toString();
                        String pwd=pass.getText().toString();
                        String cty=spl.getSelectedItem().toString();
                        String gn;
                        String st;
                        if(rgm.isChecked())
                        {
                           gn=rgm.getText().toString();
                        }
                        else
                        {
                            gn=rgf.getText().toString();
                        }
                        if(chk.isChecked())
                        {
                            st="Active";
                        }
                        else
                        {
                            st="In-Active";
                        }
                        boolean s=mydb.InsertData(fn,ln,em,pwd,gn,cty,st);
                        if(s)
                        {
                            Toast.makeText(getApplicationContext(),"Successfully inserted",Toast.LENGTH_LONG).show();
                            Intent i=new Intent(getApplicationContext(),MainActivity.class);
                            startActivity(i);
                            finish();
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),"Failed",Toast.LENGTH_LONG).show();
                        }
                    }
                }
            }
        });
    }
}