package com.example.tutorial11;

import org.json.JSONObject;

public class MyUtil
{
    public static final String USER_URL="https://jsonplaceholder.typicode.com/users";
    public static JSONObject userJSONObj=null;
}
