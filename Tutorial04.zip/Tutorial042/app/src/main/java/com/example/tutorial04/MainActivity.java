package com.example.tutorial04;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Pattern;
import android.content.Intent;
public class MainActivity extends AppCompatActivity {

    EditText uname,password;
    Button btnlogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        uname=findViewById(R.id.edtUname); /*edtUname find from activity_main file (resource file)*/
        password=findViewById(R.id.edtPassword);

        btnlogin=findViewById(R.id.btnLogin);

        //For click login button that is view alternative
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String valusername=uname.getText().toString();
                String valpassword=password.getText().toString();

                if(!Patterns.EMAIL_ADDRESS.matcher(valusername).matches()){
                    Toast.makeText(MainActivity.this, "Email Format is not valid", Toast.LENGTH_SHORT).show();

                }
                else if(valusername.equals("admin@gmail.com") && valpassword.equals("admin")){

                    Toast.makeText(MainActivity.this, "Logged in Successfully", Toast.LENGTH_SHORT).show();

                    Intent i =new Intent(MainActivity.this,WelcomeActivity.class);  /*intent has 2 nparameters(current activity(main),switch to which activity)*/
                    i.putExtra("userdata",valusername);
                    startActivity(i);
                    finish();

                }else {
                    Toast.makeText(MainActivity.this, "Your Username or Password are incorrect ", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}