package com.example.tutorial05;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SignUpDetail extends AppCompatActivity {

    TextView fn,ln,eml,pwd,cty,gnd,st;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_detail);
        fn=findViewById(R.id.txtfname);
        ln=findViewById(R.id.txtlname);
        eml=findViewById(R.id.txtuname);
        pwd=findViewById(R.id.txtpass);
        cty=findViewById(R.id.txtcity);
        gnd=findViewById(R.id.txtgender);
        st=findViewById(R.id.txtsts);
        Intent i=getIntent();
        fn.setText(i.getStringExtra("FirstName"));
        ln.setText(i.getStringExtra("LastName"));
        eml.setText(i.getStringExtra("Email"));
        pwd.setText(i.getStringExtra("Password"));
        gnd.setText(i.getStringExtra("gnder"));
        cty.setText(i.getStringExtra("city"));
        st.setText(i.getStringExtra("check"));
    }
}