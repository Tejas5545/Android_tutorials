package com.example.tutorial05;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    EditText fn,ln,eml,pass;
    Switch ceit;
    RadioButton m,f;
    Spinner cty;
    CheckBox st;
    Button btnsignup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fn=findViewById(R.id.fn);
        ln=findViewById(R.id.ln);
        eml=findViewById(R.id.eml);
        pass=findViewById(R.id.pass);
        ceit=findViewById(R.id.sw);
        cty=findViewById(R.id.cty);
        m=findViewById(R.id.gnderm);
        f=findViewById(R.id.genderf);
        st=findViewById(R.id.chkprof);
        btnsignup=findViewById(R.id.btnsup);
        final Pattern p= Patterns.EMAIL_ADDRESS;
        btnsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(ceit.isChecked())
                {
                    if(p.matcher(eml.getText().toString()).matches())
                    {

                        Intent i=new Intent(getApplicationContext(),SignUpDetail.class);
                        i.putExtra("FirstName",fn.getText().toString());
                        i.putExtra("LastName",ln.getText().toString());
                        i.putExtra("Email",eml.getText().toString());
                        i.putExtra("Password",pass.getText().toString());
                        i.putExtra("city",cty.getSelectedItem().toString());
                        if(m.isChecked())
                        {
                            i.putExtra("gnder","Male");
                        }
                        else
                        {
                            i.putExtra("gnder","Female");
                        }
                        if(st.isChecked())
                        {
                            i.putExtra("check","Active");
                        }
                        else
                        {
                            i.putExtra("check","In-Active");
                        }
                        startActivity(i);
                    }

                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Only for CE/IT",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}